/*
 * @Author: fig@吴信科 
 * @Date: 2018-11-02 21:42:06 
 * @Last Modified by: fig@吴信科
 * @Last Modified time: 2018-11-02 22:15:48
 */
window.onload = function() {

    add_all(JSON.parse(atob(GetQueryString("data"))));
}



function GetQueryString(name) { //search,查询？后面的参数，并匹配正则
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}

function add_all(json) {
    let name = "";
    let score = "";
    let img_url = "";
    let ranking = 0;
    //0 
    name = "体测成绩";
    score = "你的体测总成绩为：" + json.score + "分";
    ranking = json.scorePer.toFixed(2);
    add_car(name, img_url, score, ranking, "total-score");
    //1
    name = "身高体重";
    img_url = './images/height@3x.png';
    score = "<span>身高：" + json.height + "cm</span>" + "<span>体重：" + json.weight + "kg</span>" + "<span>分数：" + json.hwScore + "分</span>";
    ranking = json.hwScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
    // 2
    name = "肺活量";
    img_url = './images/feihuoliang@3x.png';
    score = "<span>结果：" + json.vitalCapacity + "ML</span>" + "<span>分数：" + json.vitalScore + "分</span>";
    ranking = json.vitalScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
    //3
    name = "50M";
    img_url = './images/50M@3x.png';
    score = "<span>结果：" + json.sprint + "秒</span>" + "<span>分数：" + json.sprintScore + "分</span>";
    ranking = json.sprintScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
    //4
    name = json.sex ? "1000M" : "800M";
    img_url = './images/1000M@3x.png';
    score = "<span>结果：" + Math.floor(json.run) + "分" + json.run.split(".")[1] + "秒</span>" + "<span>分数：" + json.runScore + "分</span>";
    ranking = json.runScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
    //5
    name = json.sex ? "引体向上" : "仰卧起坐";
    img_url = json.sex ? './images/yintixs.png' : './images/yanwo@3x.png';
    score = "<span>结果：" + json.pullOrSit + "个</span>" + "<span>分数：" + json.pullOrSitScore + "分</span>";
    ranking = json.pullOrSitScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
    //6
    name = "立定跳远";
    img_url = './images/long.png';
    score = "<span>结果：" + json.leap + "cm</span>" + "<span>分数：" + json.leapScore + "分</span>";
    ranking = json.leapScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
    //7
    name = "坐位体前屈";
    img_url = './images/timg2.png';
    score = "<span>结果：" + json.bodyForward + "cm</span>" + "<span>分数：" + json.forwardScore + "分</span>";
    ranking = json.forwardScorePer.toFixed(2);
    add_car(name, img_url, score, ranking);
}

function add_car(title, img_url, score, ranking, id = "subject-box") {
    const box = document.getElementById(id);
    const car = document.createElement("div");
    car.className = "car";

    car.innerHTML += "<P class='title' style=\"background-image: url('" + img_url + "');\">" + title + "</P>" +
        "<P class='score'>" + score + "</P>" +
        "<P class='ranking'>恭喜你，已超越中南民大" + ranking + "%的同学</P>";

    box.appendChild(car);
}

function tips(str) {
    if (document.getElementById("tips")) {
        document.body.removeChild(document.getElementById("tips"));
    }
    const tips = document.createElement("div");
    tips.className = "tips";
    tips.id = "tips";
    tips.innerHTML = "<div class='box'><span>" + str + "</span></div>";
    document.body.appendChild(tips);
}

function err() {
    const err = document.createElement("div");
    err.className = "err";
    err.id = "err";
    err.innerHTML = "<img src='./images/undraw_on_the_way_ldaq.png'><span>貌似出错了</span><span>待会儿再来试试吧</span>";
    document.body.appendChild(err);
}